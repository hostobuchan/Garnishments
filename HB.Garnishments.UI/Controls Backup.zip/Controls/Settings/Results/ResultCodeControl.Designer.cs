﻿namespace HB.Garnishments.UI.Controls.Settings.Results
{
    partial class ResultCodeControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblXCode = new System.Windows.Forms.Label();
            this.txtXCode = new System.Windows.Forms.TextBox();
            this.txtPS01 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPS02 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPS03 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPS04 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPS05 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPS06 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPS07 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPS08 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnEdit_01 = new System.Windows.Forms.Button();
            this.btnEdit_02 = new System.Windows.Forms.Button();
            this.btnEdit_03 = new System.Windows.Forms.Button();
            this.btnEdit_04 = new System.Windows.Forms.Button();
            this.btnEdit_05 = new System.Windows.Forms.Button();
            this.btnEdit_06 = new System.Windows.Forms.Button();
            this.btnEdit_07 = new System.Windows.Forms.Button();
            this.btnEdit_08 = new System.Windows.Forms.Button();
            this.btnDelete_08 = new System.Windows.Forms.Button();
            this.btnDelete_07 = new System.Windows.Forms.Button();
            this.btnDelete_06 = new System.Windows.Forms.Button();
            this.btnDelete_05 = new System.Windows.Forms.Button();
            this.btnDelete_04 = new System.Windows.Forms.Button();
            this.btnDelete_03 = new System.Windows.Forms.Button();
            this.btnDelete_02 = new System.Windows.Forms.Button();
            this.btnDelete_01 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblXCode
            // 
            this.lblXCode.AutoSize = true;
            this.lblXCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXCode.Location = new System.Drawing.Point(18, 30);
            this.lblXCode.Name = "lblXCode";
            this.lblXCode.Size = new System.Drawing.Size(44, 13);
            this.lblXCode.TabIndex = 0;
            this.lblXCode.Text = "XCode";
            // 
            // txtXCode
            // 
            this.txtXCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtXCode.Enabled = false;
            this.txtXCode.Location = new System.Drawing.Point(66, 27);
            this.txtXCode.Name = "txtXCode";
            this.txtXCode.ReadOnly = true;
            this.txtXCode.Size = new System.Drawing.Size(217, 20);
            this.txtXCode.TabIndex = 1;
            this.txtXCode.TabStop = false;
            this.txtXCode.Tag = "0";
            // 
            // txtPS01
            // 
            this.txtPS01.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS01.Enabled = false;
            this.txtPS01.Location = new System.Drawing.Point(66, 47);
            this.txtPS01.Name = "txtPS01";
            this.txtPS01.ReadOnly = true;
            this.txtPS01.Size = new System.Drawing.Size(217, 20);
            this.txtPS01.TabIndex = 3;
            this.txtPS01.TabStop = false;
            this.txtPS01.Tag = "PS01";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "PS01";
            // 
            // txtPS02
            // 
            this.txtPS02.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS02.Enabled = false;
            this.txtPS02.Location = new System.Drawing.Point(66, 67);
            this.txtPS02.Name = "txtPS02";
            this.txtPS02.ReadOnly = true;
            this.txtPS02.Size = new System.Drawing.Size(217, 20);
            this.txtPS02.TabIndex = 6;
            this.txtPS02.TabStop = false;
            this.txtPS02.Tag = "PS02";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "PS02";
            // 
            // txtPS03
            // 
            this.txtPS03.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS03.Enabled = false;
            this.txtPS03.Location = new System.Drawing.Point(66, 87);
            this.txtPS03.Name = "txtPS03";
            this.txtPS03.ReadOnly = true;
            this.txtPS03.Size = new System.Drawing.Size(217, 20);
            this.txtPS03.TabIndex = 9;
            this.txtPS03.TabStop = false;
            this.txtPS03.Tag = "PS03";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "PS03";
            // 
            // txtPS04
            // 
            this.txtPS04.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS04.Enabled = false;
            this.txtPS04.Location = new System.Drawing.Point(66, 107);
            this.txtPS04.Name = "txtPS04";
            this.txtPS04.ReadOnly = true;
            this.txtPS04.Size = new System.Drawing.Size(217, 20);
            this.txtPS04.TabIndex = 12;
            this.txtPS04.TabStop = false;
            this.txtPS04.Tag = "PS04";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "PS04";
            // 
            // txtPS05
            // 
            this.txtPS05.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS05.Enabled = false;
            this.txtPS05.Location = new System.Drawing.Point(66, 127);
            this.txtPS05.Name = "txtPS05";
            this.txtPS05.ReadOnly = true;
            this.txtPS05.Size = new System.Drawing.Size(217, 20);
            this.txtPS05.TabIndex = 15;
            this.txtPS05.TabStop = false;
            this.txtPS05.Tag = "PS05";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "PS05";
            // 
            // txtPS06
            // 
            this.txtPS06.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS06.Enabled = false;
            this.txtPS06.Location = new System.Drawing.Point(66, 147);
            this.txtPS06.Name = "txtPS06";
            this.txtPS06.ReadOnly = true;
            this.txtPS06.Size = new System.Drawing.Size(217, 20);
            this.txtPS06.TabIndex = 18;
            this.txtPS06.TabStop = false;
            this.txtPS06.Tag = "PS06";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "PS06";
            // 
            // txtPS07
            // 
            this.txtPS07.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS07.Enabled = false;
            this.txtPS07.Location = new System.Drawing.Point(66, 167);
            this.txtPS07.Name = "txtPS07";
            this.txtPS07.ReadOnly = true;
            this.txtPS07.Size = new System.Drawing.Size(217, 20);
            this.txtPS07.TabIndex = 21;
            this.txtPS07.TabStop = false;
            this.txtPS07.Tag = "PS07";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 170);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "PS07";
            // 
            // txtPS08
            // 
            this.txtPS08.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPS08.Enabled = false;
            this.txtPS08.Location = new System.Drawing.Point(66, 187);
            this.txtPS08.Name = "txtPS08";
            this.txtPS08.ReadOnly = true;
            this.txtPS08.Size = new System.Drawing.Size(217, 20);
            this.txtPS08.TabIndex = 24;
            this.txtPS08.TabStop = false;
            this.txtPS08.Tag = "PS08";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 190);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "PS08";
            // 
            // btnEdit_01
            // 
            this.btnEdit_01.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_01.Location = new System.Drawing.Point(289, 46);
            this.btnEdit_01.Name = "btnEdit_01";
            this.btnEdit_01.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_01.TabIndex = 4;
            this.btnEdit_01.Tag = "PS01";
            this.btnEdit_01.Text = "...";
            this.btnEdit_01.UseVisualStyleBackColor = true;
            this.btnEdit_01.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnEdit_02
            // 
            this.btnEdit_02.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_02.Location = new System.Drawing.Point(289, 66);
            this.btnEdit_02.Name = "btnEdit_02";
            this.btnEdit_02.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_02.TabIndex = 7;
            this.btnEdit_02.Tag = "PS02";
            this.btnEdit_02.Text = "...";
            this.btnEdit_02.UseVisualStyleBackColor = true;
            this.btnEdit_02.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnEdit_03
            // 
            this.btnEdit_03.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_03.Location = new System.Drawing.Point(289, 86);
            this.btnEdit_03.Name = "btnEdit_03";
            this.btnEdit_03.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_03.TabIndex = 10;
            this.btnEdit_03.Tag = "PS03";
            this.btnEdit_03.Text = "...";
            this.btnEdit_03.UseVisualStyleBackColor = true;
            this.btnEdit_03.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnEdit_04
            // 
            this.btnEdit_04.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_04.Location = new System.Drawing.Point(289, 106);
            this.btnEdit_04.Name = "btnEdit_04";
            this.btnEdit_04.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_04.TabIndex = 13;
            this.btnEdit_04.Tag = "PS04";
            this.btnEdit_04.Text = "...";
            this.btnEdit_04.UseVisualStyleBackColor = true;
            this.btnEdit_04.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnEdit_05
            // 
            this.btnEdit_05.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_05.Location = new System.Drawing.Point(289, 126);
            this.btnEdit_05.Name = "btnEdit_05";
            this.btnEdit_05.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_05.TabIndex = 16;
            this.btnEdit_05.Tag = "PS05";
            this.btnEdit_05.Text = "...";
            this.btnEdit_05.UseVisualStyleBackColor = true;
            this.btnEdit_05.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnEdit_06
            // 
            this.btnEdit_06.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_06.Location = new System.Drawing.Point(289, 146);
            this.btnEdit_06.Name = "btnEdit_06";
            this.btnEdit_06.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_06.TabIndex = 19;
            this.btnEdit_06.Tag = "PS06";
            this.btnEdit_06.Text = "...";
            this.btnEdit_06.UseVisualStyleBackColor = true;
            this.btnEdit_06.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnEdit_07
            // 
            this.btnEdit_07.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_07.Location = new System.Drawing.Point(289, 166);
            this.btnEdit_07.Name = "btnEdit_07";
            this.btnEdit_07.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_07.TabIndex = 22;
            this.btnEdit_07.Tag = "PS07";
            this.btnEdit_07.Text = "...";
            this.btnEdit_07.UseVisualStyleBackColor = true;
            this.btnEdit_07.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnEdit_08
            // 
            this.btnEdit_08.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit_08.Location = new System.Drawing.Point(289, 186);
            this.btnEdit_08.Name = "btnEdit_08";
            this.btnEdit_08.Size = new System.Drawing.Size(28, 21);
            this.btnEdit_08.TabIndex = 25;
            this.btnEdit_08.Tag = "PS08";
            this.btnEdit_08.Text = "...";
            this.btnEdit_08.UseVisualStyleBackColor = true;
            this.btnEdit_08.Click += new System.EventHandler(this.EditButton_Clicked);
            // 
            // btnDelete_08
            // 
            this.btnDelete_08.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_08.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_08.Location = new System.Drawing.Point(323, 186);
            this.btnDelete_08.Name = "btnDelete_08";
            this.btnDelete_08.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_08.TabIndex = 33;
            this.btnDelete_08.Tag = "PS08";
            this.btnDelete_08.UseVisualStyleBackColor = true;
            this.btnDelete_08.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // btnDelete_07
            // 
            this.btnDelete_07.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_07.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_07.Location = new System.Drawing.Point(323, 166);
            this.btnDelete_07.Name = "btnDelete_07";
            this.btnDelete_07.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_07.TabIndex = 32;
            this.btnDelete_07.Tag = "PS07";
            this.btnDelete_07.UseVisualStyleBackColor = true;
            this.btnDelete_07.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // btnDelete_06
            // 
            this.btnDelete_06.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_06.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_06.Location = new System.Drawing.Point(323, 146);
            this.btnDelete_06.Name = "btnDelete_06";
            this.btnDelete_06.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_06.TabIndex = 31;
            this.btnDelete_06.Tag = "PS06";
            this.btnDelete_06.UseVisualStyleBackColor = true;
            this.btnDelete_06.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // btnDelete_05
            // 
            this.btnDelete_05.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_05.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_05.Location = new System.Drawing.Point(323, 126);
            this.btnDelete_05.Name = "btnDelete_05";
            this.btnDelete_05.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_05.TabIndex = 30;
            this.btnDelete_05.Tag = "PS05";
            this.btnDelete_05.UseVisualStyleBackColor = true;
            this.btnDelete_05.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // btnDelete_04
            // 
            this.btnDelete_04.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_04.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_04.Location = new System.Drawing.Point(323, 106);
            this.btnDelete_04.Name = "btnDelete_04";
            this.btnDelete_04.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_04.TabIndex = 29;
            this.btnDelete_04.Tag = "PS04";
            this.btnDelete_04.UseVisualStyleBackColor = true;
            this.btnDelete_04.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // btnDelete_03
            // 
            this.btnDelete_03.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_03.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_03.Location = new System.Drawing.Point(323, 86);
            this.btnDelete_03.Name = "btnDelete_03";
            this.btnDelete_03.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_03.TabIndex = 28;
            this.btnDelete_03.Tag = "PS03";
            this.btnDelete_03.UseVisualStyleBackColor = true;
            this.btnDelete_03.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // btnDelete_02
            // 
            this.btnDelete_02.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_02.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_02.Location = new System.Drawing.Point(323, 66);
            this.btnDelete_02.Name = "btnDelete_02";
            this.btnDelete_02.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_02.TabIndex = 27;
            this.btnDelete_02.Tag = "PS02";
            this.btnDelete_02.UseVisualStyleBackColor = true;
            this.btnDelete_02.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // btnDelete_01
            // 
            this.btnDelete_01.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete_01.Image = global::HB.Garnishments.UI.Properties.Resources.delete;
            this.btnDelete_01.Location = new System.Drawing.Point(323, 46);
            this.btnDelete_01.Name = "btnDelete_01";
            this.btnDelete_01.Size = new System.Drawing.Size(28, 21);
            this.btnDelete_01.TabIndex = 26;
            this.btnDelete_01.Tag = "PS01";
            this.btnDelete_01.UseVisualStyleBackColor = true;
            this.btnDelete_01.Click += new System.EventHandler(this.DeleteButton_Clicked);
            // 
            // ResultCodePanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnDelete_08);
            this.Controls.Add(this.btnDelete_07);
            this.Controls.Add(this.btnDelete_06);
            this.Controls.Add(this.btnDelete_05);
            this.Controls.Add(this.btnDelete_04);
            this.Controls.Add(this.btnDelete_03);
            this.Controls.Add(this.btnDelete_02);
            this.Controls.Add(this.btnDelete_01);
            this.Controls.Add(this.btnEdit_08);
            this.Controls.Add(this.btnEdit_07);
            this.Controls.Add(this.btnEdit_06);
            this.Controls.Add(this.btnEdit_05);
            this.Controls.Add(this.btnEdit_04);
            this.Controls.Add(this.btnEdit_03);
            this.Controls.Add(this.btnEdit_02);
            this.Controls.Add(this.btnEdit_01);
            this.Controls.Add(this.txtPS08);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtPS07);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtPS06);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtPS05);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPS04);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPS03);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPS02);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPS01);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtXCode);
            this.Controls.Add(this.lblXCode);
            this.Name = "ResultCodePanel";
            this.Size = new System.Drawing.Size(354, 236);
            this.Load += new System.EventHandler(this.ResultCodePanel_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblXCode;
        private System.Windows.Forms.TextBox txtXCode;
        private System.Windows.Forms.TextBox txtPS01;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPS02;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPS03;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPS04;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPS05;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPS06;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPS07;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPS08;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnEdit_01;
        private System.Windows.Forms.Button btnEdit_02;
        private System.Windows.Forms.Button btnEdit_03;
        private System.Windows.Forms.Button btnEdit_04;
        private System.Windows.Forms.Button btnEdit_05;
        private System.Windows.Forms.Button btnEdit_06;
        private System.Windows.Forms.Button btnEdit_07;
        private System.Windows.Forms.Button btnEdit_08;
        private System.Windows.Forms.Button btnDelete_08;
        private System.Windows.Forms.Button btnDelete_07;
        private System.Windows.Forms.Button btnDelete_06;
        private System.Windows.Forms.Button btnDelete_05;
        private System.Windows.Forms.Button btnDelete_04;
        private System.Windows.Forms.Button btnDelete_03;
        private System.Windows.Forms.Button btnDelete_02;
        private System.Windows.Forms.Button btnDelete_01;
    }
}
