﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HB.Garnishments.UI.Controls.Requests
{
    public partial class AssetRequestControl : UserControl
    {
        BindingList<Data.Requests.AssetRequest> Requests { get; set; }

        public AssetRequestControl(IEnumerable<Data.Requests.AssetRequest> requests)
        {
            this.Requests = new BindingList<Data.Requests.AssetRequest>(requests.OrderByDescending(r => r.CurrentStatus.Date).ToList());
            InitializeComponent();
        }

        private void AssetRequestControl_Load(object sender, EventArgs e)
        {
            this.lstRequests.DataSource = this.Requests;
            this.lstRequests.FormatString = "E";
        }

        private void lstRequests_DoubleClick(object sender, EventArgs e)
        {
            if ((sender as ListBox)?.SelectedItem is Data.Requests.AssetRequest)
            {
                Forms.Settings.Overrides.RequestForm requestForm = new Forms.Settings.Overrides.RequestForm((sender as ListBox).SelectedItem as Data.Requests.AssetRequest);
                requestForm.RequestUpdated += RequestForm_RequestUpdated;
                requestForm.ShowDialog(this);
            }
        }

        private void RequestForm_RequestUpdated(object sender, Data.Requests.AssetRequest e)
        {
            if (InvokeRequired)
            {
                if (IsHandleCreated)
                {
                    this.Invoke(new EventHandler<Data.Requests.AssetRequest>(RequestForm_RequestUpdated), sender, e);
                }
                return;
            }

            var index = this.Requests.IndexOf(this.Requests.FirstOrDefault(r => r.ID == e.ID));
            this.Requests.RemoveAt(index);
            this.Requests.Insert(index, e);
        }
    }
}
