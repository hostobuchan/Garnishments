﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HB.SkipTracing.SCRA.Data
{
    public class Failure
    {
        public string FileNo { get; set; }
        public string Debtor { get; set; }
        public string Error { get; set; }
    }
}
