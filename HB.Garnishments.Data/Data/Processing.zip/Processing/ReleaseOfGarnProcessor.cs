﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HB.Garnishments.Data.Processing
{
    public static class ReleaseOfGarnProcessor
    {
        public static IEnumerable<RecordTypes2.YGC.RecordType09> CreateNoteRecords(IEnumerable<Tuple<string, DateTime>> accounts)
        {
            foreach (var acct in accounts)
            {
                yield return new RecordTypes2.YGC.RecordType09()
                {
                    MASCO_FILE = acct.Item1,
                    PCMT = $"FM ROG RCVD {acct.Item2:M/d/yyyy}"
                };
            }
        }
        public static IEnumerable<RecordTypes.MergePops.MergePop> CreateMergeRecords(IEnumerable<string> accounts)
        {
            foreach (var acct in accounts)
            {
                yield return new RecordTypes.MergePops.MergePop()
                {
                    FILENO = acct,
                    LLCODE = "XDEL556"
                };
            }
        }

        public static void ProcessReleases(IEnumerable<Tuple<string, DateTime>> accounts, Func<string> getSaveFile)
        {
            var notes = CreateNoteRecords(accounts).ToArray();
            var merges = CreateMergeRecords(accounts.Select(acct => acct.Item1)).ToArray();

            using (RecordTypes.MergePops.FileWriter writer = new RecordTypes.MergePops.FileWriter(getSaveFile()))
            {
                writer.WriteFile(merges);
            }
            RecordTypes.Output.Send_YGC_Imp(notes);
        }
    }
}
